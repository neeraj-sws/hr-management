<?php

namespace App\Http\Controllers\Api;

use App\Models\ApprovalRequest;
use App\Models\AttendanceEmployee;
use App\Models\AttendanceSession;
use App\Models\DailyWorkStatus;
use App\Models\EmployeeDocument;
use App\Models\LeaveRequest;
use App\Models\PerformanceReview;
use App\Services\ApprovalInbox;
use App\Services\AttendanceService;
use App\Services\WorkService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;

/** Mobile self-service: my documents, assets and performance; and a manager's team today. */
class SelfServiceController extends ApiController
{
    public function documents(Request $request): JsonResponse
    {
        $employee = $this->apiEmployee($request);
        $user = $this->apiUser($request);

        return response()->json(['data' => EmployeeDocument::where('employee_id', $employee->id)->latest()->get()->map(fn ($d) => [
            'id' => $d->id, 'name' => $d->original_name, 'category' => $d->category, 'expires_on' => $d->expires_on?->toDateString(),
            'expired' => (bool) ($d->expires_on && $d->expires_on->lt(today())),
            // Opening a private file from the phone's browser: a link signed for this user, valid 5 minutes.
            'url' => URL::temporarySignedRoute('files.document', now()->addMinutes(5), ['document' => $d->id, 'user' => $user->id]),
        ])->values()]);
    }

    public function assets(Request $request): JsonResponse
    {
        $employee = $this->apiEmployee($request);

        return response()->json(['data' => $employee->assets()->latest()->get()->map(fn ($a) => [
            'id' => $a->id, 'tag' => $a->asset_tag, 'name' => $a->name, 'status' => $a->status,
            'assigned_on' => $a->assigned_on?->toDateString(), 'returned_on' => $a->returned_on?->toDateString(),
        ])->values()]);
    }

    public function performance(Request $request, WorkService $work): JsonResponse
    {
        $employee = $this->apiEmployee($request);
        $metrics = $work->productivity(collect([$employee]), today()->startOfMonth()->toDateString(), today()->toDateString())->first();

        return response()->json([
            'month' => $metrics ? ['completed_tasks' => $metrics->completed_tasks, 'completed_late' => $metrics->completed_late, 'on_time_rate' => $metrics->on_time_rate, 'open_tasks' => $metrics->open_tasks, 'overdue_tasks' => $metrics->overdue_tasks, 'logged_hours' => $metrics->logged_hours, 'active_hours' => $metrics->active_hours, 'utilization' => $metrics->utilization] : null,
            'reviews' => PerformanceReview::with('reviewer')->where('employee_id', $employee->id)->latest('period_ends_on')->limit(12)->get()->map(fn ($r) => [
                'id' => $r->id, 'period' => $r->period_starts_on?->format('d M Y').' – '.$r->period_ends_on?->format('d M Y'), 'rating' => $r->rating,
                'strengths' => $r->strengths, 'improvements' => $r->improvements, 'reviewer' => $r->reviewer?->name, 'status' => $r->status,
            ])->values(),
        ]);
    }

    /** A manager's direct reports today: status, check-in, late, blockers, plus pending approvals. */
    public function team(Request $request, AttendanceService $attendance, ApprovalInbox $inbox): JsonResponse
    {
        $user = $this->apiUser($request);
        $own = $this->apiEmployee($request);
        $reports = AttendanceEmployee::where('is_active', true)->where('manager_id', $own->id)->orderBy('name')->get();
        abort_if($reports->isEmpty() && ! $user->canAny(['approvals.manage', 'hr.manage']), 403, 'You do not manage a team.');
        $ids = $reports->pluck('id');
        $sessions = AttendanceSession::with('employee')->whereIn('employee_id', $ids)->whereDate('work_date', today())->get()->keyBy('employee_id');
        $leave = LeaveRequest::whereIn('employee_id', $ids)->where('status', 'approved')->whereDate('starts_on', '<=', today())->whereDate('ends_on', '>=', today())->pluck('employee_id');
        $statuses = DailyWorkStatus::whereIn('employee_id', $ids)->whereDate('work_date', today())->get()->keyBy('employee_id');

        $people = $reports->map(function ($e) use ($sessions, $leave, $statuses, $attendance) {
            $s = $sessions->get($e->id);
            $state = $s ? $s->status : ($leave->contains($e->id) ? 'on_leave' : 'not_in');

            return ['id' => $e->id, 'name' => $e->name, 'designation' => $e->designation, 'state' => $state,
                'check_in' => $s?->check_in?->toIso8601String(), 'late' => $s ? $attendance->isLate($s) : false,
                'worked_seconds' => $s ? $attendance->workedSeconds($s) : 0,
                'daily_status' => (bool) $statuses->get($e->id), 'blockers' => $statuses->get($e->id)?->blockers];
        })->values();

        return response()->json([
            'summary' => ['team' => $people->count(), 'working' => $people->where('state', 'working')->count(), 'on_break' => $people->where('state', 'on_break')->count(),
                'late' => $people->where('late', true)->count(), 'on_leave' => $people->where('state', 'on_leave')->count(), 'not_in' => $people->where('state', 'not_in')->count(),
                'pending_approvals' => $inbox->pendingCount($user)],
            'people' => $people,
        ]);
    }
}
